class blutooth
		{
		static float Discount=(10.50f);
		static double Price=(2000.00);
		static String type=("Speaker");
		
		public static void main(String []args)
		{
		System.out.println("Discount"+"Price");
		System.out.println("Price"+Discount);
		System.out.println("type");
		
		}
		}