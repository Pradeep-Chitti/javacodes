class SteelbirdCyborg
		{
		public static void main(String []args)
		{
		String Colour=("Dashing Black");
		System.out.println(Colour);
		String Item=("1100Grams");
		}
		}