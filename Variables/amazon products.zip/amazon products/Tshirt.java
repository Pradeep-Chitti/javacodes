class Tshirt 
		{
		public static void main(String []args)
	
		{
		Brand("Puma");
		
		}
		static void Color( String Color)
		{
		System.out.println(Color);
		}
		static void Brand(String Brand)
		{
		System.out.println(Brand);
		}
		
		}