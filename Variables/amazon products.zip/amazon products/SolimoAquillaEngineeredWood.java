class SolimoAquillaEngineeredWood
		{
		static String Size=("Queen");
		static String Style=("Aquilla");
		
		public static void main(String []args)
		{
		String Weight=("74000Grams");
		System.out.println(Weight);
		System.out.println(Size);
		System.out.println(Style);
		}
		
		}