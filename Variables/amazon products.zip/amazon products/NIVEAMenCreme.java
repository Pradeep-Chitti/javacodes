class MiSmartBand
		{
		public static void main(String []args)
		{
		String Size=("75ml");
		System.out.println(Size);
		int Price=(2499);
		System.out.println(Price);
		float Screen(1.1f);
		System.out.println(Screen);
		}
		}