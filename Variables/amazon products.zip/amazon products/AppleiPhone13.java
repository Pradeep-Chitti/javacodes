
class AppleiPhone13
		{
		public static void main(String []args)
		{
		String Model=("IPhone");
		System.out.println(Model);
		double Price=74900.00;
		System.out.println(Price);
		}
		}