class Beardoil
		{
		public static void main(String []args)
		{
		String Size=("75ml");
		System.out.println(Size);
		float Price=(249.00f);
		System.out.println(Price);
		}
		}