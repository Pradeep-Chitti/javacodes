class GarnierMen
		{
		public static void main(String []args)
		{
		String ItemForm=("Gel");
		System.out.println(ItemForm);
		String skinType=("All");
		System.out.println(skinType);
		}
		}
		